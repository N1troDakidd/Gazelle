<?
define('ERROR_EXCEPTION', true);
require('classes/script_start.php');
