<?
define('MEMORY_EXCEPTION', true);
define('TIME_EXCEPTION', true);
define('ERROR_EXCEPTION', true);
$_SERVER['SCRIPT_FILENAME'] = 'peerupdate.php';
require('classes/script_start.php');
