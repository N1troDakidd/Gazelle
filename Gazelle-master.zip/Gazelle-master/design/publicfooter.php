		</td>
	</tr>
</table>
<div id="foot">
	<span><a href="#"><?=SITE_NAME?></a> | <a href="https://what.cd/gazelle/">Project Gazelle</a></span>
</div>
</body>
</html>
