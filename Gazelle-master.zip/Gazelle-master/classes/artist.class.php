<?
// Placeholder for if we ever decide to actaully have a model for an artist.
?>
