<h1>Error: 504</h1> Gateway timeout.
<?
notify(STATUS_CHAN,'504');
