<? View::show_header(); ?>
<div class="poetry">You've stumbled upon a door where your mind is the key. There are none who will lend you guidance; these trials are yours to conquer alone. Entering here will take more than mere logic and strategy, but the criteria are just as hidden as what they reveal. Find yourself, and you will find the very thing hidden behind this page. Beyond here is something like a utopia&#8202;&mdash;&#8202;beyond here is What.CD.</div>
<span class="center">This is a mirage.</span>
<? View::show_footer(); ?>
