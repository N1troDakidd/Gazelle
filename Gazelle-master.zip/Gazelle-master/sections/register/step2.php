<?
View::show_header('Registration Complete');
?>
<div style="width: 500px;">
	<strong>Congratulations! Your account has been created.</strong><br />
	You can now log into your account using the <a href="login.php">login</a> page.
</div>
<?
View::show_footer();
?>
