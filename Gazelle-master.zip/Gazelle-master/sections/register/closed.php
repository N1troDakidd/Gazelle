<?
View::show_header('Registration Closed');
?>
<div style="width: 500px;">
	<strong>Sorry, the site is currently invite only.</strong>
</div>
<?
View::show_footer();
?>
