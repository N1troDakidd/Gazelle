<?
$_SERVER['SCRIPT_FILENAME'] = 'irc.php'; // PHP CLI fix
require('classes/script_start.php');
