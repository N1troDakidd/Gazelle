<?
$_SERVER['SCRIPT_FILENAME'] = 'collages.php'; // PHP CLI fix
define('ERROR_EXCEPTION', true);
require('classes/script_start.php');
